# Biến Về - Tải Trận - Kỷ Năng : Son GoKu

Son GoKu - KaKarotto
